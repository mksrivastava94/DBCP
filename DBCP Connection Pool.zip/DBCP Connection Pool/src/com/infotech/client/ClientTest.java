package com.infotech.client;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.infotech.util.DBUtil;

public class ClientTest {

	public static void main(String[] args) throws SQLException {

		try {
				Connection connection = DBUtil.getDataSource().getConnection();
				Statement st = connection.createStatement(); 

			String SQL = "SELECT sysdate FROM dual";
			ResultSet rs = st.executeQuery(SQL);
			while (rs.next()) {
				String today = rs.getString(1);
				System.out.println("Today's date:"+today);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
